﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Furniture_System
{
    public partial class Items : Form
    {
        public Items()
        {
            InitializeComponent();
            populate();
            catcombo();
            typecombo();
        }
        SqlConnection con = new SqlConnection(@"Data Source=RAHUL\SQLEXPRESS;Initial Catalog=mainfurnituredb;Integrated Security=True");

        private void catcombo()
        {
            con.Open();
            string query = "select * from category";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            CatCb.DataSource = dt;
            CatCb.DisplayMember = "category_name";
            cmd.ExecuteNonQuery();
            
            con.Close();
            
        
        }


        private void typecombo()
        {
            con.Open();
            string query = "select * from type";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            TypeCb.DataSource = dt;
            TypeCb.DisplayMember = "type_name";
            cmd.ExecuteNonQuery();

            con.Close();
            

        }

        private void populate()
        {
            con.Open();
            string query = "select * from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query,con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            con.Close();
        
        }

        private void FilterByCat()
        {
            con.Open();
            string query = "select * from ItemTbl where ItCat='"+FilterCat.SelectedItem.ToString()+"' ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        private void FilterByType()
        {
            con.Open();
            string query = "select * from ItemTbl where ItType='" + FilterType.SelectedItem.ToString() + "' ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            con.Close();

        }


        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (ItName.Text == "" || PriceTb.Text == "" || QtyTb.Text == "" || CatCb.SelectedIndex == -1 || TypeCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missiing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into ItemTbl values('" + ItName.Text + "','" + CatCb.SelectedItem + "','" + TypeCb.SelectedItem.ToString() + "','" + PriceTb.Text + "','" + QtyTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Saved Successfully");
                    con.Close();
                    populate();
                    Reset();
                }
                catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Close();
        }
        int key = 0;
        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ItName.Text=ItemDGV.SelectedRows[0].Cells[1].Value.ToString();
            CatCb.SelectedItem = ItemDGV.SelectedRows[0].Cells[2].Value.ToString();
            TypeCb.SelectedItem = ItemDGV.SelectedRows[0].Cells[3].Value.ToString();
            PriceTb.Text = ItemDGV.SelectedRows[0].Cells[4].Value.ToString();
            QtyTb.Text = ItemDGV.SelectedRows[0].Cells[5].Value.ToString();
            if (ItName.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[0].Value.ToString());
            }


        }
        private void Reset()
        {
            ItName.Text = "";
            CatCb.SelectedItem = -1;
            TypeCb.SelectedItem = -1;
            PriceTb.Text = "";
            QtyTb.Text = "";
            key = 0;
        }
        private void ResestBtn_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (key==0)
            {
                MessageBox.Show("Missiing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "delete from ItemTbl where ItId="+key+" ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item delete Successfully");
                    con.Close();
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            if (ItName.Text == "" || PriceTb.Text == "" || QtyTb.Text == "" || CatCb.SelectedIndex == -1 || TypeCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missiing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "update ItemTbl set ItName='"+ItName.Text+"',ItCat='"+CatCb.SelectedItem.ToString()+"',ItType='"+TypeCb.SelectedItem.ToString()+"',ItPrice='"+PriceTb.Text+"',ItQty='"+QtyTb.Text+"' where ItId="+key+";";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Update Successfully");
                    con.Close();
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Customers obj = new Customers();
            obj.Show();
            this.Hide();
        }

        

        private void FilterCat_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FilterByCat();
        }

        private void FilterType_SelectionChangeCommitted(object sender, EventArgs e)
        {
            FilterByType();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            cat_type obj = new cat_type();
            obj.Show();
            this.Hide();
        }

        private void ItName_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void PriceTb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void QtyTb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

       
        

       
    }
}
