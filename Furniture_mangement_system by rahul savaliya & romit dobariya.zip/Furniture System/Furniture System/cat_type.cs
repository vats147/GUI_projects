﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Furniture_System
{
    public partial class cat_type : Form
    {
        public cat_type()
        {
            InitializeComponent();
            populate_cat();
            populate_type();
        }

        SqlConnection con = new SqlConnection(@"Data Source=RAHUL\SQLEXPRESS;Initial Catalog=mainfurnituredb;Integrated Security=True");

        private void populate_cat()
        {
            con.Open();
            string query = "select * from category";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            catDGV.DataSource = ds.Tables[0];
            con.Close();

        }


        private void populate_type()
        {
            con.Open();
            string query = "select * from type";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            typeDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "insert into category values('" +textBox1.Text + "','"+textBox2.Text+"')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("category Saved Successfully");
            con.Close();
            populate_cat();
           
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "delete from category where category_id=" + textBox1.Text + " ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("category delete Successfully");
            con.Close();
            populate_cat();
            
        }

        private void editbtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update category set category_name='" + textBox2.Text + "' where category_id='" + textBox1.Text + "' ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("cetegory Update Successfully");
            con.Close();
            populate_cat();
        }
       

        private void catDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = catDGV.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = catDGV.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "insert into type values('" + textBox3.Text + "','" + textBox4.Text + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("type Saved Successfully");
            con.Close();
            populate_type();
           
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "delete from type where type_id=" + textBox3.Text + " ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("type delete Successfully");
            con.Close();
            populate_type();
        }

        private void typeDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = typeDGV.SelectedRows[0].Cells[0].Value.ToString();
            textBox4.Text = typeDGV.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update type set type_name='" + textBox4.Text + "' where type_id='" + textBox3.Text + "' ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("type Update Successfully");
            con.Close();
            populate_type();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Items obj = new Items();
            obj.Show();
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        

        
       
       
        
    }
}
