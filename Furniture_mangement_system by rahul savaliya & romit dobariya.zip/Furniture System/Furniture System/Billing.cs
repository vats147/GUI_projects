﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Furniture_System
{
    public partial class Billing : Form
    {
 
        public Billing()
        {
            InitializeComponent();
            populate();
            displayCust();
           // dis();
           
        }

        SqlConnection con = new SqlConnection(@"Data Source=RAHUL\SQLEXPRESS;Initial Catalog=mainfurnituredb;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string query = "select * from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        private void displayCust()
        {
            con.Open();
            string query = "select * from CustomerTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CustomerDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        int key = 0, stock = 0;
        int CustKey = 0;
        
        private void Update()
        {

            try
            {
                int newStock = stock - Convert.ToInt32(QtyTb.Text); 
                con.Open();
                string query = "update ItemTbl set ItQty=" + newStock  + " where ItId=" + key + ";";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                //MessageBox.Show("Item Update Successfully");
                con.Close();
                populate();
                
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        int n = 0,GrdTotal=0;
        private void AddtoBillBtn_Click(object sender, EventArgs e)
        {
            if (QtyTb.Text == "" || Convert.ToInt32(QtyTb.Text) > stock)
            {
                MessageBox.Show("no stock");
            }
            else
            {
                int total = Convert.ToInt32(QtyTb.Text) * Convert.ToInt32(PriceTb.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(BillDGV);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = ProductNameTb.Text;
                newRow.Cells[2].Value = PriceTb.Text;
                newRow.Cells[3].Value = QtyTb.Text;
                newRow.Cells[1].Value = total;
                BillDGV.Rows.Add(newRow);
                GrdTotal = GrdTotal + total;
                TotalLbl.Text = "Rs"+GrdTotal;
                n++;
                Update();
            }
        }

       

        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CustNameTb.Text = CustomerDGV.SelectedRows[0].Cells[1].Value.ToString();


            if (CustNameTb.Text == "")
            {
                CustKey = 0;
            }
            else
            {
                CustKey = Convert.ToInt32(CustomerDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }
        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductNameTb.Text = ItemDGV.SelectedRows[0].Cells[1].Value.ToString();
            
            PriceTb.Text = ItemDGV.SelectedRows[0].Cells[4].Value.ToString();
            
            if (ProductNameTb.Text == "")
            {
                key = 0;
                stock = 0;
            }
            else
            {
                key = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[0].Value.ToString());
                stock = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[5].Value.ToString());
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            printDocument1.DefaultPageSettings.PaperSize=new System.Drawing.Printing.PaperSize("pprnm",285,600);
            if(printPreviewDialog1.ShowDialog()==DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void Billing_Load(object sender, EventArgs e)
        {
           
            
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {

            ViewSells obj = new ViewSells();
            obj.Show();
            this.Hide();
        }
        int prodid, prodprise, prodqty,custname, tottal, pos = 60;
        string ProdName;
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("XYZ Furniture", new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Red, new Point(80));
            e.Graphics.DrawString("ID PRODUCT PRICE QUANTITY ", new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Red, new Point(26,40));

            foreach(DataGridViewRow row in BillDGV.Rows)
            {
                prodid = Convert.ToInt32(row.Cells["Column1"].Value);
                ProdName = "" + row.Cells["Column2"].Value;
                prodprise = Convert.ToInt32(row.Cells["Column3"].Value);
                prodqty = Convert.ToInt32(row.Cells["Column4"].Value);

                //tottal = Convert.ToInt32(row.Cells["Column5"].Value);

                e.Graphics.DrawString("" + prodid, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(26, pos));
                e.Graphics.DrawString("" + ProdName, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(45, pos));
                e.Graphics.DrawString("" + prodprise, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(120, pos));
                e.Graphics.DrawString("" + prodqty, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(170, pos));
                //e.Graphics.DrawString("" + tottal, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(235, pos));
                pos = pos + 20;

            }
            e.Graphics.DrawString("Grand Total: RS = "+ GrdTotal+"/-",new Font("Century Gothic",12,FontStyle.Bold),Brushes.Crimson, new Point(50 ,pos+50));
            e.Graphics.DrawString("                ***  Thank You  ***",  new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Crimson, new Point(11,pos+85));
            BillDGV.Rows.Clear();
            BillDGV.Refresh();
            pos = 100;
            GrdTotal = 0;
        }

        private void BillDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Customers obj = new Customers();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("select * from CustomerTbl where CustPhone='"+textBox1.Text+"' ",con);
            DataTable dt = new DataTable();
            con.Open();
            da.Fill(dt);
            CustomerDGV.DataSource = dt;
            con.Close();
        }

        private void QtyTb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

      

        

       
        
        
    }
}
