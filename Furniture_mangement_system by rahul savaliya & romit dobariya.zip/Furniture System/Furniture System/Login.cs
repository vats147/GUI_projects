﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Furniture_System
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if(PasswordTb1.Text == "" || UnameTb.Text == "")
            {
                MessageBox.Show("Enter Username and Password");
            }
            else if (UnameTb.Text == "Admin" && PasswordTb1.Text == "Password")
            {

                Items obj = new Items();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect Password and Username");
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Billing obj = new Billing();
            obj.Show();
            this.Hide();
        }

        private void PasswordTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void UnameTb_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
