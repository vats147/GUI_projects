﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Furniture_System
{
    public partial class ViewSells : Form
    {
        public ViewSells()
        {
            InitializeComponent();
            populate();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            Billing obj = new Billing();
            obj.Show();
            this.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=RAHUL\SQLEXPRESS;Initial Catalog=mainfurnituredb;Integrated Security=True");

        private void populate()
        {
            con.Open();
            string query = "select * from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SellsDGV.DataSource = ds.Tables[0];
            con.Close();

        }

        private void ViewSells_Load(object sender, EventArgs e)
        {

        }
    }
}
