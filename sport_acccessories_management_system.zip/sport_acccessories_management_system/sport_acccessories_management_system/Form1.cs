﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sport_acccessories_management_system
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");

        public Form1()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Admin_panel ad = new Admin_panel();
            //admin_panel_ ad = new admin_panel_();
            //ad.Show();
            //this.Hide();

            admin_login ad = new admin_login();
            ad.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Register_Employee_detail1 WHERE Employee_id ='" + textBox1.Text +"' AND Employee_password ='" + maskedTextBox1.Text + "'", con);
            DataTable dt = new DataTable();

            cmd.Parameters.AddWithValue("@username", textBox1.Text);
            cmd.Parameters.AddWithValue("@password", maskedTextBox1.Text);
            con.Open();

            SqlDataAdapter adapt = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            adapt.Fill(ds);
            con.Close();

            int count = ds.Tables[0].Rows.Count;

            if (count == 1)
            {
               // mail = txtmail.Text;
                this.Hide();
                MessageBox.Show("Login Successful!");
                employye_panel ep = new employye_panel();
                ep.Show();
               // login l = new login();
               // l.ShowDialog();
            }
            else
            {
                MessageBox.Show("Login Failed!");
            }


        }
    }
}
