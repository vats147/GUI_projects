﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sport_acccessories_management_system
{
    public partial class employye_panel : Form
    {


        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports;Integrated Security=True");
        // SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");
        string date="2020-10-10";
        decimal price = 0;
        decimal total = 0;
        int a = 0;
            
        int empid=1;
        void refesh()
        {
            //dataGridView1.Rows.Clear();
            //   dataGridView1.ClearSelection();

            /* dataGridView1.DataSource = null;
             dataGridView1.Refresh();
             dataGridView1.DataSource = null;
             dataGridView1.DataBind();*/
            SqlCommand cmd = new SqlCommand("select * from customer_purchase_detail1", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        public employye_panel()
        {
            InitializeComponent();
            refesh();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void employye_panel_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Environment.Exit(1);
            Application.Exit();
        }

        private void button15_Click(object sender, EventArgs e)
        {

            con.Close();
            con.Open();



            //dataGridView1.Rows.Clear();

           SqlCommand cmd = new SqlCommand("select * from Product_detail where Product_id='" + textBox1.Text + "';", con);
          SqlDataReader  dr = cmd.ExecuteReader();
          int qty;
            if (dr.HasRows)
            {
                dr.Read();
                
                textBox9.Text = dr.GetValue(4).ToString();

                textBox8.Text = dr.GetValue(2).ToString();
                textBox7.Text = dr.GetValue(1).ToString();
                price=Convert.ToDecimal(dr.GetValue(4));
                qty=Convert.ToInt32(dr.GetValue(3));

            }
            total = Convert.ToDecimal(textBox9.Text) * Convert.ToInt32(textBox3.Text);

            textBox4.Text = Convert.ToString(total);

            //sda.Fill(dt);
          
            con.Close();
            /* con.Open();
             cmd = new SqlCommand("select * from Product_detail1 where Product_id='" + textBox1.Text + "';", con);
             dr = cmd.ExecuteReader();
             if (dr.HasRows)
             {
                 dr.Read();

                 textBox4.Text = dr.GetValue(1).ToString();
                 textBox3.Text = dr.GetValue(2).ToString();
                 maskedTextBox2.Text = dr.GetValue(3).ToString();
                 // comboBox1.value=dr.GetValue(2).ToString();
                 //  comboBox1.SelectedValue = dr.GetValue(2).ToString();
             }
             textBox4.ReadOnly = true;
             textBox3.ReadOnly = true;
             maskedTextBox2.ReadOnly = true;
             //sda.Fill(dt);
             //dataGridView2.DataSource = dt;

             //int m = cmd.ExecuteNonQuery();
             con.Close();*/
        }

        private void button10_Click(object sender, EventArgs e)
        {

           
            if (textBox5.Text.Length == 0 || textBox3.Text.Length == 0)
            {
                MessageBox.Show("fill all detail");

            }
            else
            {
                con.Close();
                con.Open();
               //s DataTable dt = new DataTable();
                

              // string dat = Convert.ToString(dateTimePicker1.Value);
               // MessageBox.Show(textBox1.Text+textBox2.Text+textBox3.Text+textBox4.Text+textBox5.Text+textBox6.Text+textBox7.Text+textBox8.Text);
                // cmd = new SqlCommand("insert into customer_purchase_detail1 values('"+textBox6.Text+"','"+textBox5.Text+"','"+textBox1.Text+"','"+Convert.ToDecimal(maskedTextBox2.Text)+"','"+textBox7.Text+"','"+textBox8.Text+"','"+textBox3.Text+"','"+textBox4.Text+"','"+dat+"','"+textBox2.Text+"');",con);
           //  SqlCommand  cmd = new SqlCommand("insert into customer_purchase_detail1 values('"+Convert.ToInt32(textBox6.Text)+"','"+Convert.ToString(textBox5.Text)+"','"+Convert.ToInt32( textBox1.Text)+"','"+Convert.ToDecimal(maskedTextBox2.Text)+"','"+Convert.ToString(textBox7.Text)+"','"+Convert.ToString(textBox8.Text)+"','"+Convert.ToInt32(textBox3.Text)+"','"+Convert.ToDecimal(textBox4.Text)+"','"+maskedTextBox2.Text+"','"+Convert.ToInt32(textBox2.Text)+"');",con);
          //    SqlCommand cmd = new SqlCommand("insert into customer_purchase_detail1 values("++");",con);
                SqlCommand cmd = new SqlCommand("insert into customer_purchase_detail1(Bill_id,Customer_name,sell_date_time,product_quantity,employee_id,product_id,product_category,product_brand,product_price,product_total) values('"+textBox6.Text+"','"+textBox5.Text+"','"+maskedTextBox1.Text+"','"+textBox3.Text+"','"+textBox2.Text+"','"+textBox1.Text+"','"+textBox7.Text+"','"+textBox8.Text+"','"+price+"','"+total+"');", con);
                refesh();
                cmd.ExecuteNonQuery();
                con.Close();

            }
           
        }

        private void button11_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from customer_purchase_detail1 where Bill_id='"+textBox6.Text+"'AND product_quantity='"+textBox3.Text+"';", con);
            refesh();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int a = 0;

            a++;
            con.Close();
            con.Open();
         SqlCommand   cmd = new SqlCommand("update bill_id set bll_id='" + a + "' ", con);
            cmd.ExecuteNonQuery();
            con.Close();
            this.Hide();

              print_recipt pr = new print_recipt();
             pr.Show();
        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            con.Close();
            con.Open();




            SqlCommand cmd = new SqlCommand("select * from bill_id ", con);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                textBox6.Text = dr.GetValue(0).ToString();
                a =Convert.ToInt32(textBox6.Text);


            }
            
            DataTable dt = new DataTable();
            


        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 f1 = new Form1();
            f1.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("update customer_purchase_detail1 set ", con);

            con.Close();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            refesh();
        }
    }


}