﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sport_acccessories_management_system
{
    public partial class Sales : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");

        public Sales()
        {
            InitializeComponent();
            refesh();
        }
        void refesh()
        {
            //dataGridView1.Rows.Clear();
            //   dataGridView1.ClearSelection();

            /* dataGridView1.DataSource = null;
             dataGridView1.Refresh();
             dataGridView1.DataSource = null;
             dataGridView1.DataBind();*/
            SqlCommand cmd = new SqlCommand("select * from customer_purchase_detail1", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        private void Sales_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            refesh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin_panel_item api = new admin_panel_item();
            api.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin_panel_ ap = new admin_panel_();
            ap.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin_login al = new admin_login();
            al.Show();
        }
        void s()
        {
            //dataGridView1.Rows.Clear();
            //   dataGridView1.ClearSelection();

            /* dataGridView1.DataSource = null;
             dataGridView1.Refresh();
             dataGridView1.DataSource = null;
             dataGridView1.DataBind();*/
            SqlCommand cmd = new SqlCommand("select * from customer_purchase_detail1 where employee_id='"+textBox6.Text+"'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            s();
        }
    }
}
