﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sport_acccessories_management_system
{
    public partial class admin_login : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");
        SqlCommand cmd=new SqlCommand();


        //define variable for command
        string sql = "";
        public admin_login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
                if(tblogin.Text.Length!=0 && mtbpassword.Text.Length !=0)
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Admin WHERE Admin_login_id ='" + tblogin.Text + "' AND Admin_password ='" + mtbpassword.Text + "'", con);
                    DataTable dt = new DataTable();

                    cmd.Parameters.AddWithValue("@username", tblogin.Text);
                    cmd.Parameters.AddWithValue("@password", mtbpassword.Text);
                    con.Close();
                    con.Open();

                    SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();

                    adapt.Fill(ds);
                    con.Close();

                    int count = ds.Tables[0].Rows.Count;

                    if (count == 1)
                    {
                      //  mail = txtmail.Text;
                        MessageBox.Show("Login Successful!");
                        this.Hide();
                        admin_panel_ ap = new admin_panel_();
                        ap.Show();

                       // login l = new login();
                      //  l.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Login Failed!");
                    }
                }
                else
                {
                    MessageBox.Show("Fill all field");
                }
                con.Close();
                
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
           
            
            Environment.Exit(1);
        }

        private void admin_login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }   
    }
}
