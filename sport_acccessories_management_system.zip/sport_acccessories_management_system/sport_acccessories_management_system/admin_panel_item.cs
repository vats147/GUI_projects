﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace sport_acccessories_management_system
{
    public partial class admin_panel_item : Form
    {

        int productid;
        String producut_name;
        float product_price;
        int product_category;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");

        
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr = null;
        SqlDataAdapter sda = null;
        DataTable dt = new DataTable();

        public admin_panel_item()
        {
            InitializeComponent();
            refesh();
        }
        void refesh()
        {

            con.Close();
            con.Open();

            SqlCommand cmd = new SqlCommand("select * from Product_detail", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView2.DataSource = dt;
            con.Close();
         


        }
        private void admin_panel_item_Load(object sender, EventArgs e)
        {

            SqlCommand cmd = new SqlCommand("select * from Product_category", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            comboBox1.DataSource = dt;

            comboBox1.ValueMember = "Product_category";
            comboBox1.DisplayMember = "Product_category";

          
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
       
        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Close();
                con.Open();

                cmd = new SqlCommand("insert into Product_detail values('" + Convert.ToInt32(textBox1.Text) + "','" + comboBox1.SelectedValue + "','" + comboBox2.SelectedValue + "','" + textBox2.Text +"','" +Convert.ToDecimal(textBox3.Text) + "');", con);
                //cmd = new SqlCommand("insert into Product_detail values('"+Convert.ToInt32(textBox1.Text)+"','"+textBox2.Text+"','"+comboBox1.SelectedValue+"','"+Convert.ToInt32(textBox3.Text)+"');",con);
                cmd.ExecuteNonQuery();
                con.Close();
                refesh();
                MessageBox.Show("Inserted succesufully");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Open();


                cmd = new SqlCommand("delete from Product_detail where Product_id='" + textBox1.Text + "';", con);
                int m = cmd.ExecuteNonQuery();
                con.Close();
                refesh();
                MessageBox.Show("Deleted  succesufully");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Open();


                cmd = new SqlCommand("update  Product_detail set Product_quantity='" + textBox2.Text + "',Product_price='" + Convert.ToDecimal(textBox3.Text) + "',Product_category='" + comboBox1.SelectedValue + "',Product_brand='" + comboBox2.SelectedValue + "'where Product_id='" + textBox1.Text + "';", con);
                int m = cmd.ExecuteNonQuery();
                con.Close();
                refesh();
                MessageBox.Show("Update  succesufully");
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Close();
                con.Open();



                //dataGridView1.Rows.Clear();

                cmd = new SqlCommand("select * from Product_detail where Product_id='" + textBox1.Text + "';", con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    textBox2.Text = dr.GetValue(3).ToString();
                    textBox3.Text = dr.GetValue(4).ToString();
                    comboBox2.SelectedValue = dr.GetValue(2).ToString();
                    
                    comboBox1.SelectedValue = dr.GetValue(1).ToString();

                }

                //sda.Fill(dt);
                dataGridView2.DataSource = dt;

                dataGridView2.DataSource = null;
                con.Close();

                // MessageBox.Show("Serch  succesufully");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            refesh();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            admin_panel_ ap = new admin_panel_();
            this.Close();
            ap.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Close();
            con.Open();

            cmd = new SqlCommand("select * from brand2 where brand_cat='" + comboBox1.SelectedValue + "'", con);
            sda = new SqlDataAdapter(cmd);

            dt = new DataTable();
            sda.Fill(dt);

            comboBox2.DataSource = dt;

            comboBox2.ValueMember = "brand_name";
            comboBox2.DisplayMember = "brand_name";
            con.Close();
             
           
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin_login al = new admin_login();
            al.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            refesh();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sales s = new Sales();
            s.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
