﻿namespace sport_acccessories_management_system {
    
    
    public partial class DataSet1 {
    }
}
namespace sport_acccessories_management_system {
    
    
    public partial class DataSet1 {
    }
}
namespace sport_acccessories_management_system {
    
    
    public partial class DataSet1 {
    }
}
