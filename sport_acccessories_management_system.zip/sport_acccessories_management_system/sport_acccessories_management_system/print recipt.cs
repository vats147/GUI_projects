﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
namespace sport_acccessories_management_system
{
    public partial class print_recipt : Form
    {
        //SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports;Integrated Security=True");
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");
       

        public print_recipt()
        {
            InitializeComponent();
        }

        private void print_recipt_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("select sum(product_total) from customer_purchase_detail1 where Bill_id="+textBox1.Text+";", con);
            //cmd = new SqlCommand("select * from Product_detail where Product_id='" + textBox1.Text + "';", con);
         SqlDataReader   dr = cmd.ExecuteReader();
            string totalfinal="";
            if (dr.HasRows)
            {
                dr.Read();
                totalfinal=dr.GetValue(0).ToString(); 
               // MessageBox.Show();
               // textBox2.Text = dr.GetValue(0).ToString();
               

            }
            MessageBox.Show(totalfinal);
           // MessageBox.Show();
                     con.Close();
                        con.Open();
            
                        SqlDataAdapter da = new SqlDataAdapter("select * from customer_purchase_detail1 where Bill_id='"+textBox1.Text+"'",con);
                       // DataSet1 ds = new DataSet1();
                        DataSet1 ds = new DataSet1();
                        da.Fill(ds, "DataTable1");
                        ReportDataSource datasource = new ReportDataSource("DataSet1",ds.Tables[0]);
                       this.reportViewer1.LocalReport.DataSources.Clear();
                       this.reportViewer1.LocalReport.DataSources.Add(datasource);
                       this.reportViewer1.RefreshReport();
                

                        con.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Hide();
            employye_panel ep = new employye_panel();
            ep.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
