﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sport_acccessories_management_system
{
    public partial class admin_panel_ : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-5DLUIKK\SQLEXPRESS;Initial Catalog=Sports_mangement;Integrated Security=True");
        

        int employee_id;
        String employee_name;
        string password;

        public admin_panel_()
        {
            InitializeComponent();
            //refesh();
            display();
        }
        void refesh()
        {
           
           con.Close();
            con.Open();
           
           SqlCommand cmd = new SqlCommand("select * from Register_employee_detail1", con);
           SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt=new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
          /*  con.Close();
            con.Open();
            string str = "select * from Register_Employee_detail";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            con.Close();*/

          
        }
        void display()
        {
            con.Close();
            con.Open();
           // dataGridView1.Rows.Clear();
            //dataGridView1.ItemsSource = dt.DefaultView;
           SqlCommand cmd = new SqlCommand("select * from Register_employee_detail1", con);
           SqlDataAdapter sda = new SqlDataAdapter(cmd);
           DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void admin_panel__Load(object sender, EventArgs e)
        {
            refesh();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if(textBox1.Text.Length==0||textBox2.Text.Length==0||textBox3.Text.Length==0||textBox4.Text.Length==0||textBox5.Text.Length==0||maskedTextBox1.Text.Length==0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Close();
                con.Open();
                
             SqlCommand   cmd = new SqlCommand("insert into Register_employee_detail1 values('"+textBox1.Text+"','"+textBox2.Text+"','"+maskedTextBox1.Text+"','"+textBox3.Text+"','"+textBox4.Text+"','"+textBox5.Text+"');",con);
                cmd.ExecuteNonQuery();
             
                display();

                con.Close();
                
                MessageBox.Show("Inserted succesufully");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Close();
                con.Open();

                SqlCommand cmd = new SqlCommand("delete from Register_employee_detail1 where Employee_id='" + textBox1.Text + "';", con);
                cmd.ExecuteNonQuery();

                display();

                con.Close();

                MessageBox.Show("Delete succesufully");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {

            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0 || maskedTextBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Open();


                SqlCommand cmd = new SqlCommand("update  Register_employee_detail1 set Employee_name='" + textBox2.Text + "',Employee_password='" + textBox3.Text + "',Employee_address='" + textBox4.Text + "',Employee_contactnumber='" + textBox5.Text + "',Employee_joining_date='" + maskedTextBox1.Text + "'where Employee_id='" + textBox1.Text + "';", con);
                 cmd.ExecuteNonQuery();
                con.Close();
                refesh();
                MessageBox.Show("update  succesufully");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            maskedTextBox1.Clear();
        }

        private void button15_Click(object sender, EventArgs e)
        {
          if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("please fill all detail");
            }
            else
            {
                con.Close();
                con.Open();



                
                
               SqlCommand cmd = new SqlCommand("select * from Register_employee_detail1 where Employee_id='" + textBox1.Text + "';", con);
               SqlDataReader dr = cmd.ExecuteReader();
               
                if (dr.HasRows)
                {
                    dr.Read();
                    textBox2.Text = dr.GetValue(1).ToString();
                    maskedTextBox1.Text = dr.GetValue(2).ToString();
                    textBox3.Text = dr.GetValue(3).ToString();
                    textBox4.Text = dr.GetValue(4).ToString();
                    textBox5.Text = dr.GetValue(5).ToString();
                    

                }
                DataTable dt = new DataTable();
             //   sda.Fill(dt);
               // dataGridView1.DataSource = dt;

              
                con.Close();
               
            }
        }
        //int Key;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

          
         
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // display();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            admin_panel_item api =new admin_panel_item();
            this.Hide();
            api.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            admin_login al = new admin_login();
            al.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sales s = new Sales();
            s.Show();
        }
    }
}
