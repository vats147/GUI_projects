﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fireworks_Management_System
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (UNametxt.Text == "" || PNametxt.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                if (UNametxt.Text == "Admin" && PNametxt.Text == "123")
                {
                    Form1 obj = new Form1();
                    obj.Show();
                    this.Hide();
                }
                else 
                {
                    MessageBox.Show("Invalid Username and Password");
                    UNametxt.Text = "";
                    PNametxt.Text = "";
                }
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                PNametxt.isPassword = false;
                
            }
            else
            {
                PNametxt.isPassword = true;
            }
        }

        private void UNametxt_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void PNametxt_OnValueChanged(object sender, EventArgs e)
        {

        }
    }
}
