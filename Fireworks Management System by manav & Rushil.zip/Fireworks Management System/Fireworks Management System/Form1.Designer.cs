﻿namespace Fireworks_Management_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation1 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.bunifuPages1 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Deletebtn = new System.Windows.Forms.Button();
            this.Quantitytxt = new System.Windows.Forms.TextBox();
            this.Pricetxt = new System.Windows.Forms.TextBox();
            this.ProdNametxt = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.ProductDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Editbtn = new System.Windows.Forms.Button();
            this.Savebtn = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.CatCb = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Caddress = new System.Windows.Forms.TextBox();
            this.CPhonetxt = new System.Windows.Forms.TextBox();
            this.Cnametxt = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.CustomerDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Cdeletebtn = new System.Windows.Forms.Button();
            this.Ceditbtn = new System.Windows.Forms.Button();
            this.CAddbtn = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CategoryNametxt = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.CategoryDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.CatDeletebtn = new System.Windows.Forms.Button();
            this.CatEditbtn = new System.Windows.Forms.Button();
            this.CatAddbtn = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.BProdNametxt = new System.Windows.Forms.TextBox();
            this.BPricetxt = new System.Windows.Forms.TextBox();
            this.BQntytxt = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BillSavebtn = new System.Windows.Forms.Button();
            this.GrdTotallbl = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.YourBillsDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BproductDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.BillsDGV = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.label21 = new System.Windows.Forms.Label();
            this.BRefreshbtn = new System.Windows.Forms.Button();
            this.AddtoBillbtn = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.CustomerCb = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Prodlbl = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.bunifuGradientPanel3 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Salelbl = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Custlbl = new System.Windows.Forms.Label();
            this.Custlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.bunifuPages1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductDGV)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerDGV)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CategoryDGV)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YourBillsDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BproductDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillsDGV)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.bunifuGradientPanel2.SuspendLayout();
            this.bunifuGradientPanel3.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 763);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(71, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(34, 593);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(168, 31);
            this.label36.TabIndex = 6;
            this.label36.Text = "Generate Bill";
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(34, 714);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 31);
            this.label16.TabIndex = 5;
            this.label16.Text = "LogOut";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(34, 508);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 31);
            this.label15.TabIndex = 4;
            this.label15.Text = "Dashboard";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(34, 418);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 31);
            this.label14.TabIndex = 3;
            this.label14.Text = "Billing";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(34, 325);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 31);
            this.label13.TabIndex = 2;
            this.label13.Text = "Categories";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(34, 229);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(144, 31);
            this.label12.TabIndex = 1;
            this.label12.Text = "Customers";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(34, 144);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 31);
            this.label11.TabIndex = 0;
            this.label11.Text = "Products";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // bunifuPages1
            // 
            this.bunifuPages1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages1.AllowTransitions = true;
            this.bunifuPages1.Controls.Add(this.tabPage1);
            this.bunifuPages1.Controls.Add(this.tabPage2);
            this.bunifuPages1.Controls.Add(this.tabPage3);
            this.bunifuPages1.Controls.Add(this.tabPage4);
            this.bunifuPages1.Controls.Add(this.tabPage5);
            this.bunifuPages1.Controls.Add(this.tabPage6);
            this.bunifuPages1.Location = new System.Drawing.Point(271, 0);
            this.bunifuPages1.Multiline = true;
            this.bunifuPages1.Name = "bunifuPages1";
            this.bunifuPages1.Page = this.tabPage4;
            this.bunifuPages1.PageIndex = 3;
            this.bunifuPages1.PageName = "tabPage4";
            this.bunifuPages1.PageTitle = "tabPage4";
            this.bunifuPages1.SelectedIndex = 0;
            this.bunifuPages1.Size = new System.Drawing.Size(1192, 760);
            this.bunifuPages1.TabIndex = 1;
            animation1.AnimateOnlyDifferences = false;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuPages1.Transition = animation1;
            this.bunifuPages1.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.Deletebtn);
            this.tabPage1.Controls.Add(this.Quantitytxt);
            this.tabPage1.Controls.Add(this.Pricetxt);
            this.tabPage1.Controls.Add(this.ProdNametxt);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.ProductDGV);
            this.tabPage1.Controls.Add(this.Editbtn);
            this.tabPage1.Controls.Add(this.Savebtn);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.CatCb);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1184, 731);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // Deletebtn
            // 
            this.Deletebtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.Deletebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebtn.ForeColor = System.Drawing.Color.White;
            this.Deletebtn.Location = new System.Drawing.Point(755, 272);
            this.Deletebtn.Name = "Deletebtn";
            this.Deletebtn.Size = new System.Drawing.Size(191, 48);
            this.Deletebtn.TabIndex = 29;
            this.Deletebtn.Text = "DELETE";
            this.Deletebtn.UseVisualStyleBackColor = false;
            this.Deletebtn.Click += new System.EventHandler(this.Deletebtn_Click_1);
            // 
            // Quantitytxt
            // 
            this.Quantitytxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantitytxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Quantitytxt.Location = new System.Drawing.Point(410, 202);
            this.Quantitytxt.Name = "Quantitytxt";
            this.Quantitytxt.Size = new System.Drawing.Size(200, 41);
            this.Quantitytxt.TabIndex = 28;
            // 
            // Pricetxt
            // 
            this.Pricetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pricetxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Pricetxt.Location = new System.Drawing.Point(755, 138);
            this.Pricetxt.Name = "Pricetxt";
            this.Pricetxt.Size = new System.Drawing.Size(200, 41);
            this.Pricetxt.TabIndex = 27;
            // 
            // ProdNametxt
            // 
            this.ProdNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProdNametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ProdNametxt.Location = new System.Drawing.Point(410, 134);
            this.ProdNametxt.Name = "ProdNametxt";
            this.ProdNametxt.Size = new System.Drawing.Size(200, 41);
            this.ProdNametxt.TabIndex = 26;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.White;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label30.Location = new System.Drawing.Point(640, 212);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 29);
            this.label30.TabIndex = 25;
            this.label30.Text = "Category";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label27.Location = new System.Drawing.Point(300, 215);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 29);
            this.label27.TabIndex = 24;
            this.label27.Text = "Quantity";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label24.Location = new System.Drawing.Point(676, 150);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 29);
            this.label24.TabIndex = 23;
            this.label24.Text = "Price";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label23.Location = new System.Drawing.Point(237, 147);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(167, 29);
            this.label23.TabIndex = 22;
            this.label23.Text = "Product Name";
            // 
            // ProductDGV
            // 
            this.ProductDGV.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.ProductDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.ProductDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ProductDGV.BackgroundColor = System.Drawing.Color.White;
            this.ProductDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProductDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.ProductDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ProductDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.ProductDGV.ColumnHeadersHeight = 40;
            this.ProductDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.ProductDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.ProductDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.ProductDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.ProductDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.ProductDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.ProductDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.ProductDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.ProductDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.ProductDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.ProductDGV.CurrentTheme.Name = null;
            this.ProductDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.ProductDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.ProductDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.ProductDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.ProductDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ProductDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.ProductDGV.EnableHeadersVisualStyles = false;
            this.ProductDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.ProductDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.ProductDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.ProductDGV.HeaderForeColor = System.Drawing.Color.White;
            this.ProductDGV.Location = new System.Drawing.Point(53, 396);
            this.ProductDGV.Name = "ProductDGV";
            this.ProductDGV.RowHeadersVisible = false;
            this.ProductDGV.RowTemplate.Height = 40;
            this.ProductDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ProductDGV.Size = new System.Drawing.Size(1091, 304);
            this.ProductDGV.TabIndex = 21;
            this.ProductDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            this.ProductDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ProductDGV_CellContentClick);
            // 
            // Editbtn
            // 
            this.Editbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.Editbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbtn.ForeColor = System.Drawing.Color.White;
            this.Editbtn.Location = new System.Drawing.Point(552, 271);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(170, 48);
            this.Editbtn.TabIndex = 17;
            this.Editbtn.Text = "EDIT";
            this.Editbtn.UseVisualStyleBackColor = false;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // Savebtn
            // 
            this.Savebtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.Savebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.ForeColor = System.Drawing.Color.White;
            this.Savebtn.Location = new System.Drawing.Point(350, 272);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(170, 48);
            this.Savebtn.TabIndex = 16;
            this.Savebtn.Text = "ADD";
            this.Savebtn.UseVisualStyleBackColor = false;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label17.Location = new System.Drawing.Point(533, 341);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(188, 42);
            this.label17.TabIndex = 10;
            this.label17.Text = "Product List";
            // 
            // CatCb
            // 
            this.CatCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatCb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.CatCb.FormattingEnabled = true;
            this.CatCb.Items.AddRange(new object[] {
            "Bomb",
            "Fulkani",
            "Atashbaji",
            "Chakadi"});
            this.CatCb.Location = new System.Drawing.Point(755, 197);
            this.CatCb.Name = "CatCb";
            this.CatCb.Size = new System.Drawing.Size(200, 44);
            this.CatCb.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(513, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(209, 51);
            this.label10.TabIndex = 4;
            this.label10.Text = "Fireworks";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(535, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "Manage Items";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Caddress);
            this.tabPage2.Controls.Add(this.CPhonetxt);
            this.tabPage2.Controls.Add(this.Cnametxt);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.CustomerDGV);
            this.tabPage2.Controls.Add(this.Cdeletebtn);
            this.tabPage2.Controls.Add(this.Ceditbtn);
            this.tabPage2.Controls.Add(this.CAddbtn);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1184, 731);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // Caddress
            // 
            this.Caddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Caddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Caddress.Location = new System.Drawing.Point(851, 108);
            this.Caddress.Name = "Caddress";
            this.Caddress.Size = new System.Drawing.Size(200, 41);
            this.Caddress.TabIndex = 35;
            // 
            // CPhonetxt
            // 
            this.CPhonetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CPhonetxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.CPhonetxt.Location = new System.Drawing.Point(526, 108);
            this.CPhonetxt.Name = "CPhonetxt";
            this.CPhonetxt.Size = new System.Drawing.Size(200, 41);
            this.CPhonetxt.TabIndex = 34;
            // 
            // Cnametxt
            // 
            this.Cnametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cnametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Cnametxt.Location = new System.Drawing.Point(221, 104);
            this.Cnametxt.Name = "Cnametxt";
            this.Cnametxt.Size = new System.Drawing.Size(200, 41);
            this.Cnametxt.TabIndex = 33;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label34.Location = new System.Drawing.Point(760, 120);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(85, 25);
            this.label34.TabIndex = 32;
            this.label34.Text = "Address";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label33.Location = new System.Drawing.Point(443, 120);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(69, 25);
            this.label33.TabIndex = 31;
            this.label33.Text = "Phone";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label32.Location = new System.Drawing.Point(52, 120);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(154, 25);
            this.label32.TabIndex = 30;
            this.label32.Text = "Customer Name";
            // 
            // CustomerDGV
            // 
            this.CustomerDGV.AllowCustomTheming = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.CustomerDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.CustomerDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CustomerDGV.BackgroundColor = System.Drawing.Color.White;
            this.CustomerDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CustomerDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CustomerDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CustomerDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.CustomerDGV.ColumnHeadersHeight = 40;
            this.CustomerDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.CustomerDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.CustomerDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.CustomerDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.CustomerDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.CustomerDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.CustomerDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.CustomerDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.CustomerDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.CustomerDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.CustomerDGV.CurrentTheme.Name = null;
            this.CustomerDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.CustomerDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.CustomerDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.CustomerDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.CustomerDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CustomerDGV.DefaultCellStyle = dataGridViewCellStyle6;
            this.CustomerDGV.EnableHeadersVisualStyles = false;
            this.CustomerDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.CustomerDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.CustomerDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.CustomerDGV.HeaderForeColor = System.Drawing.Color.White;
            this.CustomerDGV.Location = new System.Drawing.Point(33, 319);
            this.CustomerDGV.Name = "CustomerDGV";
            this.CustomerDGV.RowHeadersVisible = false;
            this.CustomerDGV.RowTemplate.Height = 40;
            this.CustomerDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CustomerDGV.Size = new System.Drawing.Size(1117, 369);
            this.CustomerDGV.TabIndex = 29;
            this.CustomerDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            this.CustomerDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustomerDGV_CellContentClick);
            // 
            // Cdeletebtn
            // 
            this.Cdeletebtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.Cdeletebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cdeletebtn.ForeColor = System.Drawing.Color.White;
            this.Cdeletebtn.Location = new System.Drawing.Point(737, 176);
            this.Cdeletebtn.Name = "Cdeletebtn";
            this.Cdeletebtn.Size = new System.Drawing.Size(170, 48);
            this.Cdeletebtn.TabIndex = 28;
            this.Cdeletebtn.Text = "DELETE";
            this.Cdeletebtn.UseVisualStyleBackColor = false;
            this.Cdeletebtn.Click += new System.EventHandler(this.Cdeletebtn_Click);
            // 
            // Ceditbtn
            // 
            this.Ceditbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.Ceditbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ceditbtn.ForeColor = System.Drawing.Color.White;
            this.Ceditbtn.Location = new System.Drawing.Point(537, 176);
            this.Ceditbtn.Name = "Ceditbtn";
            this.Ceditbtn.Size = new System.Drawing.Size(170, 48);
            this.Ceditbtn.TabIndex = 27;
            this.Ceditbtn.Text = "EDIT";
            this.Ceditbtn.UseVisualStyleBackColor = false;
            this.Ceditbtn.Click += new System.EventHandler(this.Ceditbtn_Click);
            // 
            // CAddbtn
            // 
            this.CAddbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.CAddbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CAddbtn.ForeColor = System.Drawing.Color.White;
            this.CAddbtn.Location = new System.Drawing.Point(342, 176);
            this.CAddbtn.Name = "CAddbtn";
            this.CAddbtn.Size = new System.Drawing.Size(170, 48);
            this.CAddbtn.TabIndex = 26;
            this.CAddbtn.Text = "ADD";
            this.CAddbtn.UseVisualStyleBackColor = false;
            this.CAddbtn.Click += new System.EventHandler(this.CAddbtn_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label18.Location = new System.Drawing.Point(511, 259);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(215, 42);
            this.label18.TabIndex = 22;
            this.label18.Text = "Customer List";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F);
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(509, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(209, 51);
            this.label9.TabIndex = 3;
            this.label9.Text = "Fireworks";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(513, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 26);
            this.label3.TabIndex = 0;
            this.label3.Text = "Manage Customers";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.CategoryNametxt);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.CategoryDGV);
            this.tabPage3.Controls.Add(this.CatDeletebtn);
            this.tabPage3.Controls.Add(this.CatEditbtn);
            this.tabPage3.Controls.Add(this.CatAddbtn);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1184, 731);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            // 
            // CategoryNametxt
            // 
            this.CategoryNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CategoryNametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.CategoryNametxt.Location = new System.Drawing.Point(548, 99);
            this.CategoryNametxt.Name = "CategoryNametxt";
            this.CategoryNametxt.Size = new System.Drawing.Size(200, 41);
            this.CategoryNametxt.TabIndex = 39;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label35.Location = new System.Drawing.Point(380, 111);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(149, 25);
            this.label35.TabIndex = 38;
            this.label35.Text = "Category Name";
            // 
            // CategoryDGV
            // 
            this.CategoryDGV.AllowCustomTheming = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.CategoryDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.CategoryDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.CategoryDGV.BackgroundColor = System.Drawing.Color.White;
            this.CategoryDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CategoryDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.CategoryDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CategoryDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.CategoryDGV.ColumnHeadersHeight = 40;
            this.CategoryDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.CategoryDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.CategoryDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.CategoryDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.CategoryDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.CategoryDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.CategoryDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.CategoryDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.CategoryDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.CategoryDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.CategoryDGV.CurrentTheme.Name = null;
            this.CategoryDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.CategoryDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.CategoryDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.CategoryDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.CategoryDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.CategoryDGV.DefaultCellStyle = dataGridViewCellStyle9;
            this.CategoryDGV.EnableHeadersVisualStyles = false;
            this.CategoryDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.CategoryDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.CategoryDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.CategoryDGV.HeaderForeColor = System.Drawing.Color.White;
            this.CategoryDGV.Location = new System.Drawing.Point(25, 319);
            this.CategoryDGV.Name = "CategoryDGV";
            this.CategoryDGV.RowHeadersVisible = false;
            this.CategoryDGV.RowTemplate.Height = 40;
            this.CategoryDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CategoryDGV.Size = new System.Drawing.Size(1129, 371);
            this.CategoryDGV.TabIndex = 37;
            this.CategoryDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            this.CategoryDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CategoryDGV_CellContentClick);
            // 
            // CatDeletebtn
            // 
            this.CatDeletebtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.CatDeletebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatDeletebtn.ForeColor = System.Drawing.Color.White;
            this.CatDeletebtn.Location = new System.Drawing.Point(753, 171);
            this.CatDeletebtn.Name = "CatDeletebtn";
            this.CatDeletebtn.Size = new System.Drawing.Size(170, 48);
            this.CatDeletebtn.TabIndex = 36;
            this.CatDeletebtn.Text = "DELETE";
            this.CatDeletebtn.UseVisualStyleBackColor = false;
            this.CatDeletebtn.Click += new System.EventHandler(this.CatDeletebtn_Click);
            // 
            // CatEditbtn
            // 
            this.CatEditbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.CatEditbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatEditbtn.ForeColor = System.Drawing.Color.White;
            this.CatEditbtn.Location = new System.Drawing.Point(516, 171);
            this.CatEditbtn.Name = "CatEditbtn";
            this.CatEditbtn.Size = new System.Drawing.Size(170, 48);
            this.CatEditbtn.TabIndex = 35;
            this.CatEditbtn.Text = "EDIT";
            this.CatEditbtn.UseVisualStyleBackColor = false;
            this.CatEditbtn.Click += new System.EventHandler(this.CatEditbtn_Click);
            // 
            // CatAddbtn
            // 
            this.CatAddbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.CatAddbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatAddbtn.ForeColor = System.Drawing.Color.White;
            this.CatAddbtn.Location = new System.Drawing.Point(278, 171);
            this.CatAddbtn.Name = "CatAddbtn";
            this.CatAddbtn.Size = new System.Drawing.Size(170, 48);
            this.CatAddbtn.TabIndex = 34;
            this.CatAddbtn.Text = "ADD";
            this.CatAddbtn.UseVisualStyleBackColor = false;
            this.CatAddbtn.Click += new System.EventHandler(this.CatAddbtn_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label19.Location = new System.Drawing.Point(495, 250);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(206, 42);
            this.label19.TabIndex = 30;
            this.label19.Text = "Category List";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label8.Location = new System.Drawing.Point(492, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(209, 51);
            this.label8.TabIndex = 3;
            this.label8.Text = "Fireworks";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(496, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "Manage Categories";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.label41);
            this.tabPage4.Controls.Add(this.label40);
            this.tabPage4.Controls.Add(this.label39);
            this.tabPage4.Controls.Add(this.label38);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Controls.Add(this.BProdNametxt);
            this.tabPage4.Controls.Add(this.BPricetxt);
            this.tabPage4.Controls.Add(this.BQntytxt);
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.button1);
            this.tabPage4.Controls.Add(this.BillSavebtn);
            this.tabPage4.Controls.Add(this.GrdTotallbl);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.YourBillsDGV);
            this.tabPage4.Controls.Add(this.BproductDGV);
            this.tabPage4.Controls.Add(this.BillsDGV);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.BRefreshbtn);
            this.tabPage4.Controls.Add(this.AddtoBillbtn);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.CustomerCb);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1184, 731);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label41.Location = new System.Drawing.Point(229, 133);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(134, 25);
            this.label41.TabIndex = 49;
            this.label41.Text = "Total Quantity";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label40.Location = new System.Drawing.Point(229, 209);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(157, 25);
            this.label40.TabIndex = 48;
            this.label40.Text = "Product Quantity";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label39.Location = new System.Drawing.Point(19, 209);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(136, 25);
            this.label39.TabIndex = 47;
            this.label39.Text = "Product Name";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label38.Location = new System.Drawing.Point(19, 133);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(154, 25);
            this.label38.TabIndex = 46;
            this.label38.Text = "Customer Name";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label37.Location = new System.Drawing.Point(19, 56);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(159, 25);
            this.label37.TabIndex = 45;
            this.label37.Text = "Customer Phone";
            // 
            // BProdNametxt
            // 
            this.BProdNametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BProdNametxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BProdNametxt.Location = new System.Drawing.Point(20, 237);
            this.BProdNametxt.Name = "BProdNametxt";
            this.BProdNametxt.ReadOnly = true;
            this.BProdNametxt.Size = new System.Drawing.Size(194, 34);
            this.BProdNametxt.TabIndex = 44;
            // 
            // BPricetxt
            // 
            this.BPricetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BPricetxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BPricetxt.Location = new System.Drawing.Point(230, 161);
            this.BPricetxt.Name = "BPricetxt";
            this.BPricetxt.ReadOnly = true;
            this.BPricetxt.Size = new System.Drawing.Size(200, 34);
            this.BPricetxt.TabIndex = 43;
            // 
            // BQntytxt
            // 
            this.BQntytxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BQntytxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BQntytxt.Location = new System.Drawing.Point(230, 237);
            this.BQntytxt.Name = "BQntytxt";
            this.BQntytxt.Size = new System.Drawing.Size(200, 34);
            this.BQntytxt.TabIndex = 42;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.textBox1.Location = new System.Drawing.Point(20, 161);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(200, 34);
            this.textBox1.TabIndex = 41;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DodgerBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(234, 73);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 48);
            this.button1.TabIndex = 39;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BillSavebtn
            // 
            this.BillSavebtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.BillSavebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillSavebtn.ForeColor = System.Drawing.Color.White;
            this.BillSavebtn.Location = new System.Drawing.Point(515, 414);
            this.BillSavebtn.Name = "BillSavebtn";
            this.BillSavebtn.Size = new System.Drawing.Size(152, 48);
            this.BillSavebtn.TabIndex = 37;
            this.BillSavebtn.Text = "Save Bill";
            this.BillSavebtn.UseVisualStyleBackColor = false;
            this.BillSavebtn.Click += new System.EventHandler(this.BillSavebtn_Click);
            // 
            // GrdTotallbl
            // 
            this.GrdTotallbl.AutoSize = true;
            this.GrdTotallbl.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrdTotallbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.GrdTotallbl.Location = new System.Drawing.Point(200, 698);
            this.GrdTotallbl.Name = "GrdTotallbl";
            this.GrdTotallbl.Size = new System.Drawing.Size(66, 30);
            this.GrdTotallbl.TabIndex = 36;
            this.GrdTotallbl.Text = "Total";
            this.GrdTotallbl.Click += new System.EventHandler(this.GrdTotallbl_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label22.Location = new System.Drawing.Point(169, 367);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(153, 42);
            this.label22.TabIndex = 35;
            this.label22.Text = "Client Bill";
            // 
            // YourBillsDGV
            // 
            this.YourBillsDGV.AllowCustomTheming = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.YourBillsDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.YourBillsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.YourBillsDGV.BackgroundColor = System.Drawing.Color.White;
            this.YourBillsDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.YourBillsDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.YourBillsDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.YourBillsDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.YourBillsDGV.ColumnHeadersHeight = 40;
            this.YourBillsDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column6,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.YourBillsDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.YourBillsDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.YourBillsDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.YourBillsDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.YourBillsDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.YourBillsDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.YourBillsDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.YourBillsDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.YourBillsDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.YourBillsDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.YourBillsDGV.CurrentTheme.Name = null;
            this.YourBillsDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.YourBillsDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.YourBillsDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.YourBillsDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.YourBillsDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.YourBillsDGV.DefaultCellStyle = dataGridViewCellStyle12;
            this.YourBillsDGV.EnableHeadersVisualStyles = false;
            this.YourBillsDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.YourBillsDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.YourBillsDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.YourBillsDGV.HeaderForeColor = System.Drawing.Color.White;
            this.YourBillsDGV.Location = new System.Drawing.Point(24, 412);
            this.YourBillsDGV.Name = "YourBillsDGV";
            this.YourBillsDGV.RowHeadersVisible = false;
            this.YourBillsDGV.RowTemplate.Height = 40;
            this.YourBillsDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.YourBillsDGV.Size = new System.Drawing.Size(459, 286);
            this.YourBillsDGV.TabIndex = 34;
            this.YourBillsDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Name";
            this.Column6.Name = "Column6";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Product";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Quantity";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Price";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Total";
            this.Column5.Name = "Column5";
            // 
            // BproductDGV
            // 
            this.BproductDGV.AllowCustomTheming = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            this.BproductDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.BproductDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BproductDGV.BackgroundColor = System.Drawing.Color.White;
            this.BproductDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BproductDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.BproductDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BproductDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.BproductDGV.ColumnHeadersHeight = 40;
            this.BproductDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.BproductDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.BproductDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.BproductDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.BproductDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.BproductDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.BproductDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.BproductDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.BproductDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.BproductDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.BproductDGV.CurrentTheme.Name = null;
            this.BproductDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.BproductDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.BproductDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.BproductDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.BproductDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BproductDGV.DefaultCellStyle = dataGridViewCellStyle15;
            this.BproductDGV.EnableHeadersVisualStyles = false;
            this.BproductDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.BproductDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.BproductDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.BproductDGV.HeaderForeColor = System.Drawing.Color.White;
            this.BproductDGV.Location = new System.Drawing.Point(587, 67);
            this.BproductDGV.Name = "BproductDGV";
            this.BproductDGV.RowHeadersVisible = false;
            this.BproductDGV.RowTemplate.Height = 40;
            this.BproductDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BproductDGV.Size = new System.Drawing.Size(578, 240);
            this.BproductDGV.TabIndex = 33;
            this.BproductDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            this.BproductDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BproductDGV_CellContentClick);
            // 
            // BillsDGV
            // 
            this.BillsDGV.AllowCustomTheming = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            this.BillsDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.BillsDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BillsDGV.BackgroundColor = System.Drawing.Color.White;
            this.BillsDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BillsDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.BillsDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Crimson;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BillsDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.BillsDGV.ColumnHeadersHeight = 40;
            this.BillsDGV.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(196)))), ((int)(((byte)(206)))));
            this.BillsDGV.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.BillsDGV.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.BillsDGV.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.BillsDGV.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.BillsDGV.CurrentTheme.BackColor = System.Drawing.Color.Crimson;
            this.BillsDGV.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.BillsDGV.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.Crimson;
            this.BillsDGV.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.BillsDGV.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.BillsDGV.CurrentTheme.Name = null;
            this.BillsDGV.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            this.BillsDGV.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.BillsDGV.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.BillsDGV.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            this.BillsDGV.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(208)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(114)))), ((int)(((byte)(138)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BillsDGV.DefaultCellStyle = dataGridViewCellStyle18;
            this.BillsDGV.EnableHeadersVisualStyles = false;
            this.BillsDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(184)))), ((int)(((byte)(196)))));
            this.BillsDGV.HeaderBackColor = System.Drawing.Color.Crimson;
            this.BillsDGV.HeaderBgColor = System.Drawing.Color.Empty;
            this.BillsDGV.HeaderForeColor = System.Drawing.Color.White;
            this.BillsDGV.Location = new System.Drawing.Point(687, 400);
            this.BillsDGV.Name = "BillsDGV";
            this.BillsDGV.RowHeadersVisible = false;
            this.BillsDGV.RowTemplate.Height = 40;
            this.BillsDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BillsDGV.Size = new System.Drawing.Size(478, 286);
            this.BillsDGV.TabIndex = 32;
            this.BillsDGV.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Crimson;
            this.BillsDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.BillsDGV_CellContentClick);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label21.Location = new System.Drawing.Point(6, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(102, 26);
            this.label21.TabIndex = 30;
            this.label21.Text = "Customer";
            // 
            // BRefreshbtn
            // 
            this.BRefreshbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.BRefreshbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BRefreshbtn.ForeColor = System.Drawing.Color.White;
            this.BRefreshbtn.Location = new System.Drawing.Point(45, 304);
            this.BRefreshbtn.Name = "BRefreshbtn";
            this.BRefreshbtn.Size = new System.Drawing.Size(169, 48);
            this.BRefreshbtn.TabIndex = 27;
            this.BRefreshbtn.Text = "Refresh";
            this.BRefreshbtn.UseVisualStyleBackColor = false;
            this.BRefreshbtn.Click += new System.EventHandler(this.BRefreshbtn_Click);
            // 
            // AddtoBillbtn
            // 
            this.AddtoBillbtn.BackColor = System.Drawing.Color.DodgerBlue;
            this.AddtoBillbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddtoBillbtn.ForeColor = System.Drawing.Color.White;
            this.AddtoBillbtn.Location = new System.Drawing.Point(242, 304);
            this.AddtoBillbtn.Name = "AddtoBillbtn";
            this.AddtoBillbtn.Size = new System.Drawing.Size(162, 48);
            this.AddtoBillbtn.TabIndex = 26;
            this.AddtoBillbtn.Text = "Add To Bill";
            this.AddtoBillbtn.UseVisualStyleBackColor = false;
            this.AddtoBillbtn.Click += new System.EventHandler(this.AddtoBillbtn_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Tai Le", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label20.Location = new System.Drawing.Point(820, 340);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(165, 42);
            this.label20.TabIndex = 22;
            this.label20.Text = "Billing List";
            // 
            // CustomerCb
            // 
            this.CustomerCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerCb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.CustomerCb.FormattingEnabled = true;
            this.CustomerCb.Location = new System.Drawing.Point(20, 84);
            this.CustomerCb.Name = "CustomerCb";
            this.CustomerCb.Size = new System.Drawing.Size(198, 37);
            this.CustomerCb.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(416, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 32);
            this.label7.TabIndex = 3;
            this.label7.Text = "Fireworks";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(407, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "Selling Module";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.bunifuGradientPanel2);
            this.tabPage5.Controls.Add(this.bunifuGradientPanel3);
            this.tabPage5.Controls.Add(this.bunifuGradientPanel1);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1184, 731);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.Prodlbl);
            this.bunifuGradientPanel2.Controls.Add(this.label28);
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.Green;
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.Green;
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(449, 250);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(254, 215);
            this.bunifuGradientPanel2.TabIndex = 4;
            // 
            // Prodlbl
            // 
            this.Prodlbl.AutoSize = true;
            this.Prodlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.Prodlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Prodlbl.Location = new System.Drawing.Point(81, 115);
            this.Prodlbl.Name = "Prodlbl";
            this.Prodlbl.Size = new System.Drawing.Size(64, 29);
            this.Prodlbl.TabIndex = 1;
            this.Prodlbl.Text = "Num";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(61, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(134, 36);
            this.label28.TabIndex = 0;
            this.label28.Text = "Products";
            // 
            // bunifuGradientPanel3
            // 
            this.bunifuGradientPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel3.BackgroundImage")));
            this.bunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel3.Controls.Add(this.Salelbl);
            this.bunifuGradientPanel3.Controls.Add(this.label31);
            this.bunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.Green;
            this.bunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel3.GradientTopRight = System.Drawing.Color.Green;
            this.bunifuGradientPanel3.Location = new System.Drawing.Point(842, 250);
            this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
            this.bunifuGradientPanel3.Quality = 10;
            this.bunifuGradientPanel3.Size = new System.Drawing.Size(254, 215);
            this.bunifuGradientPanel3.TabIndex = 4;
            // 
            // Salelbl
            // 
            this.Salelbl.AutoSize = true;
            this.Salelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F);
            this.Salelbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Salelbl.Location = new System.Drawing.Point(86, 115);
            this.Salelbl.Name = "Salelbl";
            this.Salelbl.Size = new System.Drawing.Size(64, 29);
            this.Salelbl.TabIndex = 1;
            this.Salelbl.Text = "Num";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(79, 38);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(89, 36);
            this.label31.TabIndex = 0;
            this.label31.Text = "Sales";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.Custlbl);
            this.bunifuGradientPanel1.Controls.Add(this.Custlabel);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.LimeGreen;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(38, 250);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(254, 215);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // Custlbl
            // 
            this.Custlbl.AutoSize = true;
            this.Custlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Custlbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Custlbl.Location = new System.Drawing.Point(78, 122);
            this.Custlbl.Name = "Custlbl";
            this.Custlbl.Size = new System.Drawing.Size(64, 29);
            this.Custlbl.TabIndex = 1;
            this.Custlbl.Text = "Num";
            // 
            // Custlabel
            // 
            this.Custlabel.AutoSize = true;
            this.Custlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Custlabel.ForeColor = System.Drawing.Color.White;
            this.Custlabel.Location = new System.Drawing.Point(50, 38);
            this.Custlabel.Name = "Custlabel";
            this.Custlabel.Size = new System.Drawing.Size(157, 36);
            this.Custlabel.TabIndex = 0;
            this.Custlabel.Text = "Customers";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(473, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 51);
            this.label1.TabIndex = 2;
            this.label1.Text = "Fireworks";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(477, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(196, 26);
            this.label6.TabIndex = 0;
            this.label6.Text = "Fireworks Analytics";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button2);
            this.tabPage6.Controls.Add(this.comboBox1);
            this.tabPage6.Controls.Add(this.reportViewer1);
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1184, 731);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DodgerBlue;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(142, 33);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(170, 48);
            this.button2.TabIndex = 35;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(332, 41);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(178, 33);
            this.comboBox1.TabIndex = 3;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Location = new System.Drawing.Point(25, 118);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1012, 561);
            this.reportViewer1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1475, 763);
            this.Controls.Add(this.bunifuPages1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.bunifuPages1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductDGV)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerDGV)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CategoryDGV)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.YourBillsDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BproductDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillsDGV)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.bunifuGradientPanel2.ResumeLayout(false);
            this.bunifuGradientPanel2.PerformLayout();
            this.bunifuGradientPanel3.ResumeLayout(false);
            this.bunifuGradientPanel3.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button Cdeletebtn;
        private System.Windows.Forms.Button Ceditbtn;
        private System.Windows.Forms.Button CAddbtn;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button CatDeletebtn;
        private System.Windows.Forms.Button CatEditbtn;
        private System.Windows.Forms.Button CatAddbtn;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button BRefreshbtn;
        private System.Windows.Forms.Button AddtoBillbtn;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox CustomerCb;
        private Bunifu.UI.WinForms.BunifuDataGridView CustomerDGV;
        private Bunifu.UI.WinForms.BunifuDataGridView CategoryDGV;
        private Bunifu.UI.WinForms.BunifuDataGridView BproductDGV;
        private Bunifu.UI.WinForms.BunifuDataGridView BillsDGV;
        private System.Windows.Forms.Label label22;
        private Bunifu.UI.WinForms.BunifuDataGridView YourBillsDGV;
        private System.Windows.Forms.Label GrdTotallbl;
        private System.Windows.Forms.Button BillSavebtn;
        private System.Windows.Forms.TabPage tabPage1;
        private Bunifu.UI.WinForms.BunifuDataGridView ProductDGV;
        private System.Windows.Forms.Button Editbtn;
        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox CatCb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label Custlbl;
        private System.Windows.Forms.Label Custlabel;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private System.Windows.Forms.Label Prodlbl;
        private System.Windows.Forms.Label label28;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel3;
        private System.Windows.Forms.Label Salelbl;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.TabPage tabPage6;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox Quantitytxt;
        private System.Windows.Forms.TextBox Pricetxt;
        private System.Windows.Forms.TextBox ProdNametxt;
        private System.Windows.Forms.TextBox Caddress;
        private System.Windows.Forms.TextBox CPhonetxt;
        private System.Windows.Forms.TextBox Cnametxt;
        private System.Windows.Forms.TextBox CategoryNametxt;
        private System.Windows.Forms.TextBox BProdNametxt;
        private System.Windows.Forms.TextBox BPricetxt;
        private System.Windows.Forms.TextBox BQntytxt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button Deletebtn;
    }
}

