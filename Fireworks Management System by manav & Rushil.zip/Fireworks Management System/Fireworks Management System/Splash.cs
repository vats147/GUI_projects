﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fireworks_Management_System
{
    public partial class Splash : Form
    {
        public Splash()
        {
            InitializeComponent();
        }

        int starpos = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            starpos += 1;
            MyProgress.Value = starpos;
            if (MyProgress.Value == 100)
            {
                MyProgress.Value = 0;
                timer1.Stop();

                Form2 log = new Form2();
                log.Show();
                this.Hide();
            }
        }

        private void Splash_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void MyProgress_progressChanged(object sender, EventArgs e)
        {

        }
    }
}
