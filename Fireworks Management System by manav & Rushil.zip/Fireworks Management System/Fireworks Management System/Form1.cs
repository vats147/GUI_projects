﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;

namespace Fireworks_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            display_product();
            Catadd();
             

            DisplayElements("Product_tbl", ProductDGV);
        }

        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-PRQ0LNBJ\MANAV5606;Initial Catalog=Manav;Integrated Security=True");

        private void label11_Click(object sender, EventArgs e)
        {

            bunifuPages1.SetPage(0);
            display_product();
            Catadd();
            //Catname();
            DisplayElements("Product_tbl",ProductDGV);
            
        }

        private void label12_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(1);
            DisplayElements("Customer_tbl",CustomerDGV);
        }

        private void label13_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(2);
            DisplayElements("Category_tbl",CategoryDGV);
        }

        private void label14_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(3);
            DisplayElements("Product_tbl", BproductDGV);
            DisplayElements("Sales_tbl", BillsDGV);
            GetCustomer();
            Catadd();
            
        }

        private void label15_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(4);
            CountCustomer();
            CountProducts();
            SumAmount();
            
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Product_tbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Prodlbl.Text = dt.Rows[0][0].ToString() + " Items";

            con.Close();
        }
        }

        private void label36_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(5);
            CustomerCbbbb();
        }

        private void DisplayElements(string Tname, Bunifu.UI.WinForms.BunifuDataGridView DGV)
        {
            con.Close();
            con.Open();
            string Query = "select * from "+Tname+"";
            SqlDataAdapter sda = new SqlDataAdapter(Query, con);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            DGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if (ProdNametxt.Text == "" || Quantitytxt.Text == "" || Pricetxt.Text == "" || CatCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Product_tbl(ProdName,ProdCat,ProdPrice,ProdQty) values(@PN,@PC,@PP,@PQ)",con);
                    cmd.Parameters.AddWithValue("@PN",ProdNametxt.Text);
                    cmd.Parameters.AddWithValue("@PC", CatCb.Text.ToString());
                    cmd.Parameters.AddWithValue("@PP", Pricetxt.Text);
                    cmd.Parameters.AddWithValue("@PQ", Quantitytxt.Text);
                    cmd.ExecuteNonQuery();
                    
                    MessageBox.Show("Product Added");
                    
                    con.Close();
                    DisplayElements("Product_tbl", ProductDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key;
        private void ProductDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Key = Convert.ToInt32(ProductDGV.Rows[e.RowIndex].Cells[0].Value.ToString());
           /* ProdNametxt.Text=ProductDGV.Rows[e.RowIndex].Cells[1].Value.ToString();
            Quantitytxt.Text = ProductDGV.Rows[e.RowIndex].Cells[2].Value.ToString();
            Pricetxt.Text = ProductDGV.Rows[e.RowIndex].Cells[3].Value.ToString();
            CatCb.Text = ProductDGV.Rows[e.RowIndex].Cells[4].Value.ToString();*/
            /*Key = Convert.ToInt32(ProductDGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            ProdNametxt.Text = ProductDGV.SelectedRows[0].Cells[1].Value.ToString();
            Quantitytxt.Text = ProductDGV.SelectedRows[0].Cells[2].Value.ToString();
            Pricetxt.Text = ProductDGV.SelectedRows[0].Cells[3].Value.ToString();
            CatCb.Text = ProductDGV.SelectedRows[0].Cells[4].Value.ToString();*/
            if (ProductDGV.SelectedRows.Count > 0) // make sure user select at least 1 row 
            {
                string jobId = ProductDGV.SelectedRows[0].Cells[1].Value + string.Empty;
                string quantity = ProductDGV.SelectedRows[0].Cells[2].Value + string.Empty;
                string userId = ProductDGV.SelectedRows[0].Cells[3].Value + string.Empty;

                ProdNametxt.Text = jobId;
                Quantitytxt.Text = quantity;
                Pricetxt.Text = userId;
            }
            
        }


       /* private void ProductDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Key = Convert.ToInt32(ProductDGV.Rows[e.RowIndex].Cells[0].Value.ToString());
            ProdNametxt.Text = ProductDGV.SelectedRows[0].Cells[1].Value.ToString();
            Quantitytxt.Text = ProductDGV.SelectedRows[0].Cells[2].Value.ToString();
            Pricetxt.Text = ProductDGV.SelectedRows[0].Cells[3].Value.ToString();
            CatCb.Text = ProductDGV.SelectedRows[0].Cells[4].Value.ToString();
            if (ProdNametxt.Text == "")
            {
                Key = 0;
            }

            else
            {
                Key = Convert.ToInt32(ProductDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }*/


        private void Editbtn_Click(object sender, EventArgs e)
        {
            if (ProdNametxt.Text == "" || Quantitytxt.Text == "" || Pricetxt.Text == "" || CatCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("update Product_tbl set ProdName=@PN,ProdCat=@PC,ProdPrice=@PP,ProdQty=@PQ where ProdId = @PKey", con);
                    cmd.Parameters.AddWithValue("@PN", ProdNametxt.Text);
                    cmd.Parameters.AddWithValue("@PC", CatCb.SelectedIndex.ToString());
                    cmd.Parameters.AddWithValue("@PP", Pricetxt.Text);
                    cmd.Parameters.AddWithValue("@PQ", Quantitytxt.Text);
                    cmd.Parameters.AddWithValue("@PKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Updated");
                    con.Close();
                    DisplayElements("Product_tbl", ProductDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }


        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show("Missing Information");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from Product_tbl where ProdId=@PKey", con);
                    cmd.Parameters.AddWithValue("@PKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Product Deleted");
                    con.Close();
                    DisplayElements("Product_tbl", ProductDGV);

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }



        private void CAddbtn_Click(object sender, EventArgs e)
        {
            if (Cnametxt.Text == "" || CPhonetxt.Text == "" || Caddress.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Customer_tbl(CustName,CustPhone,CustAddress) values(@CN,@CP,@CA)", con);
                    cmd.Parameters.AddWithValue("@CN", Cnametxt.Text);
                    cmd.Parameters.AddWithValue("@CP", CPhonetxt.Text);
                    cmd.Parameters.AddWithValue("@CA", Caddress.Text);
                   
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Added");
                    con.Close();
                    DisplayElements("Customer_tbl",CustomerDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int CKey = 0;
        private void CustomerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Cnametxt.Text = CustomerDGV.SelectedRows[0].Cells[1].Value.ToString();
            CPhonetxt.Text = CustomerDGV.SelectedRows[0].Cells[2].Value.ToString();
            Caddress.Text = CustomerDGV.SelectedRows[0].Cells[3].Value.ToString();

            if (Cnametxt.Text == "")
            {
                CKey = 0;
            }
            else 
            {
                CKey = Convert.ToInt32(CustomerDGV.SelectedRows[0].Cells[0].Value.ToString());
            }

        }

       

        private void Cdeletebtn_Click(object sender, EventArgs e)
        {
            if (CKey == 0)
            {
                MessageBox.Show("Missing Information");

            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from Customer_tbl where CustId=@CKey", con);
                    cmd.Parameters.AddWithValue("@CKey", CKey);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Deleted");
                    con.Close();
                    DisplayElements("Customer_tbl", CustomerDGV);

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void Ceditbtn_Click(object sender, EventArgs e)
        {
            if (Cnametxt.Text == "" || CPhonetxt.Text == "" || Caddress.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                   // SqlCommand cmd = new SqlCommand("update Customer_tbl set CustName=@CN,CustPhone=@CP,CustAddress=@CA where CustId = @CKey", con);
                    SqlCommand cmd = new SqlCommand("update Customer_tbl set CustName='" + Cnametxt.Text.ToString() + "',CustPhone='" + CPhonetxt.Text.ToString()+ "',CustAddress='"+Caddress.Text.ToString()+"'  where CustName='" + Cnametxt.Text.ToString() + "'", con);
                    /*cmd.Parameters.AddWithValue("@CN", Cnametxt.Text);
                    cmd.Parameters.AddWithValue("@CP", CPhonetxt.Text);
                    cmd.Parameters.AddWithValue("@CA", Caddress.Text);
                    cmd.Parameters.AddWithValue("@CKey", CKey);*/

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    DisplayElements("Customer_tbl", CustomerDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CatAddbtn_Click(object sender, EventArgs e)
        {
            if (CategoryNametxt.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Category_tbl(CatName) values(@CN)", con);
                    cmd.Parameters.AddWithValue("@CN", CategoryNametxt.Text);
                    
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Added");
                    con.Close();
                    DisplayElements("Category_tbl", CategoryDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        

        int CatKey = 0;
        private void CategoryDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            CategoryNametxt.Text = CategoryDGV.SelectedRows[0].Cells[1].Value.ToString();

            if (CategoryNametxt.Text == "")
            {
                CatKey = 0;
            }
            else
            {
                CatKey = Convert.ToInt32(CategoryDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void CatDeletebtn_Click(object sender, EventArgs e)
        {
            /*if (CatKey == 0)
            {
                MessageBox.Show("Missing Information");

            }
            else
            {
                try
                {*/
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from Category_tbl where CatName='" + CategoryNametxt .Text.ToString()+ "'", con);
                    //cmd.Parameters.AddWithValue("@CatKey", CatKey);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Category Deleted");
                    con.Close();
                    DisplayElements("Category_tbl", CategoryDGV);

                /*}
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }*/
        }

        private void CatEditbtn_Click(object sender, EventArgs e)
        {
            if (CategoryNametxt.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("update Category_tbl set CatName=@CN where CatId = @CKey", con);
                    cmd.Parameters.AddWithValue("@CN", CategoryNametxt.Text);
                    cmd.Parameters.AddWithValue("@CKey", CatKey);
            
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    DisplayElements("Category_tbl", CategoryDGV);
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        int BPKey = 0;
        int stock = 0;
        private void BproductDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            BProdNametxt.Text = BproductDGV.SelectedRows[0].Cells[1].Value.ToString();

            BPricetxt.Text = BproductDGV.SelectedRows[0].Cells[3].Value.ToString();

            if (BProdNametxt.Text == "")
            {
                BPKey = 0;
                stock = 0;
            }

            else
            {
                BPKey = Convert.ToInt32(BproductDGV.SelectedRows[0].Cells[0].Value.ToString());
                stock = Convert.ToInt32(BproductDGV.SelectedRows[0].Cells[2].Value.ToString());
            }
        }

        private void update()
        {
            try
            {
                int newStock = stock - Convert.ToInt32(BQntytxt.Text);
                con.Open();
                string query = "update Product_tbl set ProdQty="+newStock+"where ProdId="+BPKey+";";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
                DisplayElements("Product_tbl", BproductDGV);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        
        }

        int n = 0;
        int GrdTotal = 0;
        private void AddtoBillbtn_Click(object sender, EventArgs e)
        {
            if (BQntytxt.Text == "") 
            {
                MessageBox.Show("Enter The Quantity");
            }
            else if (Convert.ToInt32(BQntytxt.Text) > stock)
            {
                MessageBox.Show("Not Enough Stock");
            }
            else 
            {
                int total = Convert.ToInt32(BQntytxt.Text) * Convert.ToInt32(BPricetxt.Text);
                DataGridViewRow newrow = new DataGridViewRow();
                
                newrow.CreateCells(YourBillsDGV);
                newrow.Cells[0].Value = n + 1;
                newrow.Cells[1].Value = textBox1.Text;
                newrow.Cells[2].Value = BProdNametxt.Text;
                newrow.Cells[3].Value = BQntytxt.Text;
                newrow.Cells[4].Value = BPricetxt.Text;
                newrow.Cells[5].Value = total;
                YourBillsDGV.Rows.Add(newrow);
                n++;
                GrdTotal = GrdTotal + total;
                GrdTotallbl.Text = "Rs" + GrdTotal;
                update();
            }
        }

        private void GetCustomer() 
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select CustPhone from Customer_tbl", con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CustPhone",typeof(string));
            dt.Load(Rdr);
            CustomerCb.ValueMember = "CustPhone";
            CustomerCb.DataSource = dt;


            con.Close();
        }

        private void BRefreshbtn_Click(object sender, EventArgs e)
        {
            
            BPricetxt.Text = "";
            BQntytxt.Text = "";
            BProdNametxt.Text = "";
        }

        private void BillSavebtn_Click(object sender, EventArgs e)
        {
            if (CustomerCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Sales_tbl(Customer,CustomerName,SAmount,SDate)values(@CN,@CNN,@SA,@SD)", con);
                    cmd.Parameters.AddWithValue("@CN", CustomerCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CNN", textBox1.Text.ToString());
                    cmd.Parameters.AddWithValue("@SA", GrdTotal);
                    cmd.Parameters.AddWithValue("@SD", DateTime.Today.Date);
                    

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated");
                    con.Close();
                    DisplayElements("Sales_tbl", BillsDGV);
                    BPricetxt.Text = "";
                    BQntytxt.Text = "";
                    BProdNametxt.Text = "";

                    con.Close();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }


        private void CountCustomer() 
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Customer_tbl",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Custlbl.Text = dt.Rows[0][0].ToString()+" Customers";

            con.Close();
        }

        private void CountProducts()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select Count(*) from Product_tbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Prodlbl.Text = dt.Rows[0][0].ToString() + " Items";

            con.Close();
        }

        private void Catadd() {
            con.Close();
           
           
            SqlDataAdapter sda = new SqlDataAdapter("select * from Category_tbl",con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            CatCb.DataSource=dt;
           CatCb.DisplayMember ="CatName";
            con.Close();
        
        }

      

        private void SumAmount()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select Sum(SAmount) from Sales_tbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Salelbl.Text = "Rs "+dt.Rows[0][0].ToString();

            con.Close();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            Form2 obj = new Form2();
            obj.Show();
            this.Hide();
        }

       

        

        private void Form1_Load(object sender, EventArgs e)
        {
            display_product();
            Catadd();
            CustomerCbbbb();
            this.reportViewer1.RefreshReport();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            
            con.Close();
            con.Open();
            
           string Query = "Select * from Customer_tbl where CustPhone='"+CustomerCb.Text.ToString()+"'";
           SqlCommand cmd = new SqlCommand(Query,con);
           SqlDataAdapter sda = new SqlDataAdapter(cmd);
           DataTable dt = new DataTable();
           sda.Fill(dt);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                textBox1.Text = dr.GetValue(1).ToString();
            }
            con.Close();
        }

        private void BillsDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void CustomerCbbbb()
        {
            con.Close();


            SqlDataAdapter sda = new SqlDataAdapter("Select * from Customer_tbl", con);
            DataTable dt = new DataTable();
            con.Open();
            sda.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "CustName";
            con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Sales_tbl where CustomerName='" + comboBox1.Text.ToString()+ "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            ReportDataSource rd = new ReportDataSource("DataSet1",dt);
            reportViewer1.LocalReport.ReportPath = @"D:\GUI_SRS\Fireworks Management System\Fireworks Management System\Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(rd);
            reportViewer1.RefreshReport();

            con.Close();
        }

        private void GrdTotallbl_Click(object sender, EventArgs e)
        {

        }

        private void Deletebtn_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from Product_tbl where ProdId='" +Key+ "'", con);
            
            cmd.ExecuteNonQuery();
            MessageBox.Show("Product Deleted");
            con.Close();
            DisplayElements("Product_tbl", ProductDGV);
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Sales_tbl where CustomerName='" + comboBox1.Text.ToString() + "'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            ReportDataSource rd = new ReportDataSource("DataSet1", dt);
            reportViewer1.LocalReport.ReportPath = @"D:\GUI_SRS\Fireworks Management System\Fireworks Management System\Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(rd);
            reportViewer1.RefreshReport();

            con.Close();
        }

        private void display_product()
        {
            con.Close();
            con.Open();
            string str = "select * from Product_tbl";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            con.Close();


        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        

       
    }
}
